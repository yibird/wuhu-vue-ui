Wuhu File Viewer archive demo.
Open the files on the left to preview them without extracting.